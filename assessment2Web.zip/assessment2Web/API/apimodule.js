
const express = require("express");
const connection = require("./crowdfunding_db");


connection.connect();

const router = express.Router();
//1
router.get("/", (req, res) => {
    connection.query("select fundraiser.FUNDRAISER_ID,fundraiser.ORGANIZER,fundraiser.CAPTION,fundraiser.CITY,category.name from fundraiser inner join category on fundraiser.category_id = category.category_id where active = 1", (err, result) => {
        if (err) {
            console.error("Error while retrieve the data");
        } else {
            res.send(result);
        }
    })
});
//2
router.get("/category", (req, res) => {
    connection.query("select NAME from category", (err, result) => {
        if (err) {
            console.error("Error while retrieve the data");
        } else {
            res.send(result);
        }
    })
});
//3
router.get('/search', (req, res) => {

    var query = 'select fundraiser.FUNDRAISER_ID,fundraiser.ORGANIZER,fundraiser.CAPTION,fundraiser.CITY,category.name from fundraiser inner join category on fundraiser.category_id = category.category_id where active = 1';
    if (req.query.category) query += "and category.NAME = '" + req.query.category + "'"
    if (req.query.organizer) query += "and fundraiser.ORGANIZER = '" + req.query.organizer + "'"
    if (req.query.city) query += "and fundraiser.CITY = '" + req.query.city + "'"
    connection.query(query, (err, results) => {
        if (err) throw err;
        res.send(results);
    });
});
//4
router.get("/details/:fundraiser_id", (req, res) => {
    connection.query("select * from fundraiser inner join category on fundraiser.category_id = category.category_id where fundraiser.FUNDRAISER_ID=" + req.params.fundraiser_id, (err, result) => {
        if (err) {
            console.error("Error while retrieve the data");
        } else {
            res.send(result);
        }
    })
});

module.exports = router;
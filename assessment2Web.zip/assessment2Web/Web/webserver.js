const express = require("express")
const path = require("path")
const app = express()
app.use(express.static("Resource"))

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname__ + "/Resource/index.html"));
});
app.get("/search", (req, res) => {
    res.sendFile(path.join(__dirname + "/Resource/search.html"));
});
app.get("/details", (req, res) => {
    res.sendFile(path.join(__dirname + "/Resource/details.html"));
});

app.listen(8081, () => {
    console.log("Webserver is running at 127.0.0.1:8081")
})
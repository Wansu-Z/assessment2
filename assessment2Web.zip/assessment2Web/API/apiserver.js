const express = require("express");
const cors = require("cors");
const api = require("./apimodule");

//create app
const app = express();

//middleware
app.use(cors());
app.use("/api", api);


app.listen(8080, () => {
    console.log("Apiserver is running at 127.0.0.1:8080")
});

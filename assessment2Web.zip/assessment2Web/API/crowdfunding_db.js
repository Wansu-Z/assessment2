const dbDetails = require("./database-details");

const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: dbDetails.host,
    user: dbDetails.user,
    password: dbDetails.password,
    database: dbDetails.database
});
module.exports = connection;
module.exports =
{
    host: "localhost",
    user: "root",
    password: "zws760206",
    database: "crowdfunding_db"
};